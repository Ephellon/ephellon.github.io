A Pen created at CodePen.io. You can find this one at https://codepen.io/Ephellon/pen/pwweeo.

 A fantastic JavaScript interpreter! JavaScript/Python/Swift Syntax with ES7 recommendations and regular updates :D This "New" version simply makes the code more "public" friendly (proper variable names, commentation, etc.)